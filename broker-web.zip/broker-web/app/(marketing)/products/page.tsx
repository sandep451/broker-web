export default function Page() {
  return (
    <main className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-3xl font-semibold">Products</h1>
      <p className="mt-3 text-slate-700">Equity, F&O, IPO, ETFs, and more — describe your offering clearly.</p>
      <div className="mt-6 rounded-2xl border bg-white p-6 text-sm text-slate-700">
        Replace this content with your real product copy, screenshots, and FAQs.
      </div>
    </main>
  );
}
